---
name: Institutional Modernist
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf3'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d5e3fc'
  on-surface: '#0d1c2e'
  on-surface-variant: '#45464f'
  inverse-surface: '#233144'
  inverse-on-surface: '#eaf1ff'
  outline: '#767680'
  outline-variant: '#c6c5d0'
  surface-tint: '#4f5c8e'
  primary: '#000f3f'
  on-primary: '#ffffff'
  primary-container: '#172554'
  on-primary-container: '#808dc2'
  inverse-primary: '#b7c4fd'
  secondary: '#755b00'
  on-secondary: '#ffffff'
  secondary-container: '#fccc38'
  on-secondary-container: '#6f5600'
  tertiary: '#181401'
  on-tertiary: '#ffffff'
  tertiary-container: '#2d280e'
  on-tertiary-container: '#988f6d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4fd'
  on-primary-fixed: '#071747'
  on-primary-fixed-variant: '#374475'
  secondary-fixed: '#ffdf90'
  secondary-fixed-dim: '#f0c12c'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#584400'
  tertiary-fixed: '#ede3bb'
  tertiary-fixed-dim: '#d0c7a1'
  on-tertiary-fixed: '#201c04'
  on-tertiary-fixed-variant: '#4d472a'
  background: '#f8f9ff'
  on-background: '#0d1c2e'
  surface-variant: '#d5e3fc'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style

The design system is built on a foundation of **Modern Minimalism** tailored for an educational environment. It balances the authority and reliability of a school institution with the efficiency of a high-end SaaS dashboard. The aesthetic prioritizes clarity, utilizing generous whitespace and a structured information hierarchy to reduce cognitive load for administrators and staff.

The personality is professional, orderly, and trustworthy. By combining a deep institutional Navy with a vibrant Yellow accent, the UI feels energetic yet disciplined. Visual elements use subtle roundedness and thin strokes to maintain a contemporary feel without appearing overly playful or informal.

## Colors

The palette uses a 70/20/10 distribution rule to ensure visual balance. 
- **Primary Navy (#172554)** serves as the "anchor," used for high-level navigation, sidebar backgrounds, and primary headings to establish authority.
- **Primary Yellow (#F4C430)** is the high-visibility accent. It is reserved for Call-to-Action (CTA) elements, active states, and critical highlights.
- **Soft Yellow (#FFF4CC)** acts as a supporting tint for large-surface highlights or badges, preventing the UI from feeling too heavy.
- **Neutral/Surface colors** utilize a cool-toned slate gray for secondary text and a crisp off-white background to ensure the interface feels airy and clean.

## Typography

This design system utilizes **Plus Jakarta Sans** for all levels to maintain a cohesive, modern geometric feel. The type scale is optimized for dashboard environments where data density and legibility are paramount. 

- **Headlines:** Use Primary Navy to maintain institutional branding.
- **Body Text:** Use Slate (#475569) for standard reading to reduce eye strain compared to pure black.
- **Labels:** Small labels utilize medium weights and subtle letter-spacing for increased scanability in data tables and form fields.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy for desktop dashboards, centering content within a 1440px max-width container to prevent line-lengths from becoming unreadable on ultra-wide monitors.

- **Grid Model:** A 12-column system with 24px gutters.
- **Sidebar:** A fixed-width sidebar (280px) sits on the left, using the Primary Navy background.
- **Rhythm:** An 8px base grid (n*8) governs all padding and margins to ensure mathematical harmony.
- **Responsibility:** On mobile devices, the 12-column grid collapses to a single column with 16px side margins. The sidebar transforms into a bottom-sheet or a hidden drawer menu.

## Elevation & Depth

To maintain a clean and professional aesthetic, this design system avoids heavy shadows in favor of **Tonal Layers** and **Low-Contrast Outlines**.

1.  **Level 0 (Background):** #F8FAFC - The base canvas.
2.  **Level 1 (Surface):** #FFFFFF - Used for cards and main content areas. Features a 1px border of #E2E8F0.
3.  **Level 2 (Hover/Active):** A very soft ambient shadow (0px 4px 12px rgba(23, 37, 84, 0.05)) is applied only when an element requires interaction focus.
4.  **Level 3 (Modals/Popovers):** Standard elevation with a more defined but still soft shadow (0px 12px 32px rgba(0, 0, 0, 0.08)).

Depth is primarily communicated through color blocking (the Navy sidebar vs. the Light background) rather than physical extrusion.

## Shapes

The design system employs a **Rounded (Level 2)** shape language. This ensures a friendly and modern appearance that isn't as rigid as sharp corners, yet remains professional enough for a school environment.

- **Standard Elements (Buttons, Inputs):** 0.5rem (8px).
- **Large Elements (Cards, Modals):** 1rem (16px).
- **Small Elements (Badges, Tooltips):** 0.25rem (4px).
- **Interactive States:** Focus rings should follow the curvature of the element with a 2px offset.

## Components

### Buttons
- **Primary:** Background #F4C430 (Yellow), Text #172554 (Navy). Bold weight.
- **Secondary:** Background #172554 (Navy), Text #FFFFFF.
- **Outline:** Transparent background, 1px Border #E2E8F0, Text #475569.

### Input Fields
- White background with #E2E8F0 border.
- On focus, the border changes to #172554 with a soft navy glow.
- Labels are #475569 in `label-sm` typography.

### Cards
- White background, 1px solid #E2E8F0 border.
- Padding should be consistent at 24px (`stack-lg`).
- Header sections within cards should have a thin bottom border to separate titles from content.

### Chips & Badges
- Used for parking status (e.g., "Available", "Occupied").
- Utilize Soft Yellow (#FFF4CC) for neutral highlights.
- Use status colors with 10% opacity for backgrounds and 100% opacity for text (e.g., Success Green text on light green background).

### Navigation Sidebar
- Background: #172554.
- Inactive items: White with 60% opacity.
- Active item: Background #F4C430, Text #172554, with a 4px left-side indicator or full pill-shape highlight.